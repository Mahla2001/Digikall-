# Digikala Clone

#### Digikala Clone using `HTML , CSS`

It's not fully responsive. [Main Site](digikala.com) .\
builded with only `HTML` and `CSS`

Clone it and enjoy !
